/*
$(function(){
	$("img[name=imgname]").each(function(){
		var offset=$(this).offset();
		$(this).click(function(){
			$("#ju").CSS({"top":offset.top,"left":offset.left+20}).show(1000);
		})
	})
	
})
*/
$(function(){
	$(".wbot_no").each(function(){
		var offset=$(this).offset();
		$(this).click(function(){
			$("#ju").css({"top":offset.top,"left":offset.left+200}).show(1000);
		})
	})
	$("#ju a").click(function(){
		$("#ju").hide(1000);
	})
})
